package com.example.carassistance.DB.Models;

public class Lokasi {
    public int idLokasi, hargaLokasi;
    public String namaLokasi, alamatLokasi;
    public double latLokasi, longLokasi;
}
