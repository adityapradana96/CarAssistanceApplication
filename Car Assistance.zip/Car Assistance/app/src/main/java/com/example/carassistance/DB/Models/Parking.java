package com.example.carassistance.DB.Models;

public class Parking {
    public int idParking, idMember;
    public String namaLokasi, alamatLokasi, hargaLokasi, tanggalParkir;

    public Parking(int idMember, String namaLokasi, String alamatLokasi, String tanggalParkir, String hargaLokasi){
        this.idMember = idMember;
        this.namaLokasi = namaLokasi;
        this.alamatLokasi = alamatLokasi;
        this.tanggalParkir = tanggalParkir;
        this.hargaLokasi = hargaLokasi;
    }
}
