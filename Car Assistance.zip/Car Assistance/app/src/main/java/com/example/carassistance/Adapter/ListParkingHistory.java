package com.example.carassistance.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.carassistance.DB.DBHelper;
import com.example.carassistance.DB.Database;
import com.example.carassistance.R;

import java.util.Vector;

public class ListParkingHistory extends BaseAdapter {

    Context ctx;
    int idMember;

    public static Vector<String> namaLokasi = new Vector<>();
    public static Vector<String> alamatLokasi = new Vector<>();
    public static Vector<String> tanggalParkir = new Vector<>();
    public static Vector<String> totalHarga = new Vector<>();
    public static Vector<Integer> idParking = new Vector<>();

    public ListParkingHistory(Context ctx, int idMember, Vector<String> namaLokasi, Vector<String> alamatLokasi, Vector<String> tanggalParkir, Vector<String> totalHarga, Vector<Integer> idParking) {
        this.ctx = ctx;
        this.idMember = idMember;
        this.namaLokasi = namaLokasi;
        this.alamatLokasi = alamatLokasi;
        this.tanggalParkir = tanggalParkir;
        this.totalHarga = totalHarga;
        this.idParking = idParking;
    }

    @Override
    public int getCount() {
        return namaLokasi.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View parking = LayoutInflater.from(ctx).inflate(R.layout.listmybookings, null, false);

        TextView txtNamaLokasi = parking.findViewById(R.id.MyBookingsNamaParkir);
        TextView txtAlamatLokasi = parking.findViewById(R.id.MyBookingsAlamatParkir);
        TextView txtTanggalParkir = parking.findViewById(R.id.MyBookingsTanggalParkir);
        TextView txtTotalHarga = parking.findViewById(R.id.MyBookingsTotalHarga);

        txtNamaLokasi.setText(namaLokasi.get(position));
        txtAlamatLokasi.setText(alamatLokasi.get(position));
        txtTanggalParkir.setText(tanggalParkir.get(position));
        txtTotalHarga.setText(totalHarga.get(position));

        Button btnDelete = parking.findViewById(R.id.MyBookingsCancel);

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                builder.setMessage("Do you want to delete this booking?");

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        DBHelper helper = new DBHelper(ctx);
                        SQLiteDatabase db = helper.getWritableDatabase();

                        String query = String.format("DELETE FROM parkings WHERE idParking = "+ idParking.get(position));
                        db.execSQL(query);

                        for (int i = 0; i < Database.parking.size(); i++){
                            int idParking = Database.parking.get(i).idParking;
                            Log.d("Ini idPark belom diapus", ""+idParking);
                        }

                        for(int i = 0; i < Database.parking.size(); i++){
                            if(idParking.get(position) == Database.parking.get(i).idParking){
                                    Database.parking.remove(i);
                            }
                        }

                        for (int i = 0; i < Database.parking.size(); i++){
                            int idParking = Database.parking.get(i).idParking;
                            Log.d("Ini idPark abis diapus", ""+idParking);
                        }

                        namaLokasi.remove(position);
                        alamatLokasi.remove(position);
                        tanggalParkir.remove(position);
                        totalHarga.remove(position);
                        idParking.remove(position);

                        notifyDataSetChanged();

                        Database.exampleSelect(ctx);
                    }
                });

                builder.setNegativeButton("No", null);

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        return parking;
    }
}
