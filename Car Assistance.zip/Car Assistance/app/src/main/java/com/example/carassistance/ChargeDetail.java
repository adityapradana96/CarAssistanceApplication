package com.example.carassistance;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.carassistance.DB.Database;

public class ChargeDetail extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    TextView txtNamaLokasi, txtAlamatLokasi, txtTotalHarga;
    Button btnMap, btnOrder;
    Spinner spnHour;

    final int SEND_SMS_PERMISSION_REQUEST_CODE = 1;

    void init(){
        txtNamaLokasi = findViewById(R.id.DetailChargeNama);
        txtAlamatLokasi = findViewById(R.id.DetailChargeAlamat);
        txtTotalHarga = findViewById(R.id.totalpembayaran_textview_detail);

        btnMap = findViewById(R.id.DetailChargeMaps);
        btnOrder = findViewById(R.id.DetailChargeButtonOrder);

        spnHour = findViewById(R.id.Spinner_DetailCharge);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_charge_detail);

        init();

        spnHour.setOnItemSelectedListener(this);

        Intent getData = getIntent();
        final String namaLokasi = getData.getStringExtra("namaLokasi");
        final String alamatLokasi = getData.getStringExtra("alamatLokasi");
        final Double latLokasi = getData.getDoubleExtra("latLokasi", 0);
        final Double longLokasi = getData.getDoubleExtra("longLokasi", 0);
        final int idMember = getData.getIntExtra("idMember", 0);
        final String telepon = getData.getStringExtra("teleponMember");

        txtNamaLokasi.setText(namaLokasi);
        txtAlamatLokasi.setText(alamatLokasi);

        if (checkPermission(Manifest.permission.SEND_SMS)){

        }else{
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SEND_SMS_PERMISSION_REQUEST_CODE);
        }

        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cekMap = new Intent(ChargeDetail.this, MapActivity.class);
                cekMap.putExtra("latLokasi", latLokasi);
                cekMap.putExtra("longLokasi", longLokasi);
                cekMap.putExtra("namaLokasi", namaLokasi);
                startActivity(cekMap);
            }
        });

        Integer[] items = new Integer[]{1,2,3,4,5,6};
        ArrayAdapter<Integer> adapter = new ArrayAdapter<Integer>(this,android.R.layout.simple_spinner_item, items);
        spnHour.setAdapter(adapter);

        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String totalHarga = txtTotalHarga.getText().toString();

                if(checkPermission(Manifest.permission.SEND_SMS)){
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(telepon, null, "Thank you for using our recharge" +"\n"+
                                    "Location: "+ namaLokasi +"\n"+
                                    "Total Price: "+ totalHarga,
                            null, null);
                    Toast.makeText(ChargeDetail.this,"Thank you for using our recharge", Toast.LENGTH_SHORT).show();

                    Database.insertCharge(idMember, namaLokasi, alamatLokasi, totalHarga, ChargeDetail.this);
                }else{
                    Toast.makeText(ChargeDetail.this, "Permission Denied!", Toast.LENGTH_SHORT).show();
                }

                Intent home = new Intent(ChargeDetail.this, HomeActivity.class);
                home.putExtra("idMember", idMember);
                home.putExtra("teleponMember", telepon);
                startActivity(home);
                finish();
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        int hour = Integer.parseInt(spnHour.getSelectedItem().toString());
        int harga = hour * 12000;

        String totalHarga = Integer.toString(harga);

        txtTotalHarga = findViewById(R.id.totalpembayaran_textview_detail);
        txtTotalHarga.setText("Rp "+ totalHarga);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public boolean checkPermission(String permission){
        int check = ContextCompat.checkSelfPermission(this, permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }
}
