package com.example.carassistance.Adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.carassistance.ChargeDetail;
import com.example.carassistance.DB.Database;
import com.example.carassistance.DB.Models.Lokasi;
import com.example.carassistance.R;

public class ListRechargeAdapter extends BaseAdapter {
    Context ctx;
    int idMember;
    String telepon;

    public ListRechargeAdapter(Context ctx, int idMember, String telepon) {
        this.ctx = ctx;
        this.idMember = idMember;
        this.telepon = telepon;
    }

    @Override
    public int getCount() {
        return Database.lokasi.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View detailRecharge = LayoutInflater.from(ctx).inflate(R.layout.listchargespot, null, false);

        final Lokasi l = Database.lokasi.get(position);

        TextView namaCharge = detailRecharge.findViewById(R.id.ListNamaCharge);
        TextView alamatCharge = detailRecharge.findViewById(R.id.ListAlamatCharge);

        namaCharge.setText(l.namaLokasi);
        alamatCharge.setText(l.alamatLokasi);

        detailRecharge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent chargeDetail = new Intent(ctx, ChargeDetail.class);
                chargeDetail.putExtra("idLokasi", l.idLokasi);
                chargeDetail.putExtra("namaLokasi", l.namaLokasi);
                chargeDetail.putExtra("alamatLokasi", l.alamatLokasi);
                chargeDetail.putExtra("latLokasi", l.latLokasi);
                chargeDetail.putExtra("longLokasi", l.longLokasi);
                chargeDetail.putExtra("idMember", idMember);
                chargeDetail.putExtra("teleponMember", telepon);
                ctx.startActivity(chargeDetail);
            }
        });
        return detailRecharge;
    }
}

