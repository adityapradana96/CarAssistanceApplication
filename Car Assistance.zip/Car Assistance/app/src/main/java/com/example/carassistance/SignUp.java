package com.example.carassistance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.carassistance.DB.Database;

public class SignUp extends AppCompatActivity {
    EditText fullname,email, password, phonenumber;
    Button signup;

    public boolean EmailCheck(String email){
        int jumlahat = 0;
        for (int i = 0; i < email.length();i++){
            if (email.charAt(i) == '@'){
                jumlahat++;
            }
        }
        if(jumlahat ==1){
            return true;
        } else {
            return false;
        }
    }
    public static boolean PasswordCheck (String password) {
        char a;
        boolean Uppercase = false;
        boolean Lowercase = false;
        boolean Numeric = false;

        for(int i=0; i < password.length(); i++) {
            a = password.charAt(i);

            if (Character.isUpperCase(a)) {
                Uppercase = true;
            } else if (Character.isLowerCase(a)) {
                Lowercase = true;
            } else if( Character.isDigit(a)) {
                Numeric = true;
            }
            if(Uppercase == true && Lowercase == true && Numeric == true){
                return true;
            }
        }
        return false;
    }

    public static boolean PhoneCheck(String phone) {
        return android.util.Patterns.PHONE.matcher(phone).matches();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        fullname =findViewById(R.id.SignUp_FullName);
        email = findViewById(R.id.SignUp_Email);
        password = findViewById(R.id.SignUp_Password);
        phonenumber = findViewById(R.id.SignUp_PhoneNumber);
        signup = findViewById(R.id.SignUp_Button);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(fullname.getText().toString().isEmpty()){
                    fullname.setError("Name must be filled !");

                }else if(!fullname.getText().toString().contains(" ")) {
                    fullname.setError("Name must contain 2 words !");

                }else if(email.getText().toString().isEmpty()){
                    email.setError("Email must be filled !");

                }else if (!email.getText().toString().contains(".") || !email.getText().toString().contains("@")) {
                    email.setError("Email must have @ & . !");

                }else if (email.getText().toString().contains("@.") || email.getText().toString().contains(".@")){
                    email.setError("@ & . Can't be side by side !");

                }else if (EmailCheck(email.getText().toString()) == false) {
                    email.setError("There's must be pnly one @ !");

                }else if(password.getText().toString().isEmpty()){
                    password.setError("Password must be filled !");

                }else if (password.getText().toString().length()<5 ){
                    password.setError("Password must be at least 5 characters !");

                }else if (PasswordCheck(password.getText().toString()) == false) {
                    password.setError("Password should contain 1 Uppercase, Lowercase & Number !");

                }else if(phonenumber.getText().toString().isEmpty()){
                    phonenumber.setError("Phone number must be filled !");

                }else if(!phonenumber.getText().toString().startsWith("+62")) {
                    phonenumber.setError("Phone number should starts with +62!");

                }else if(PhoneCheck(phonenumber.getText().toString()) == false){
                    phonenumber.setError("Phone number is not numeric !");

                }
                else{
                    String valNama = fullname.getText().toString();
                    String valEmail = email.getText().toString();
                    String valPassword = password.getText().toString();
                    String valTelepon = phonenumber.getText().toString();

                    Database.insertUser(valNama, valEmail, valPassword, valTelepon, SignUp.this);

                    Toast.makeText(SignUp.this, "Sign Up Success", Toast.LENGTH_SHORT).show();
                    Intent keLogin = new Intent(SignUp.this, SignIn.class);
                    startActivity(keLogin);
                }
            }
        });
    }
}
