package com.example.carassistance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import com.example.carassistance.Adapter.ListChargeHistory;
import com.example.carassistance.DB.Database;

import java.util.Vector;

public class OrderHistory extends AppCompatActivity {

    public static Vector<String> namaLokasi = new Vector<>();
    public static Vector<String> alamatLokasi = new Vector<>();
    public static Vector<String> totalHarga = new Vector<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        Intent getData = getIntent();
        final int idMember = getData.getIntExtra("idMember",0);

        ListView listCharge = findViewById(R.id.ListViewOrderHistory);

        namaLokasi.clear();
        alamatLokasi.clear();
        totalHarga.clear();

        for (int i = 0; i < Database.charge.size(); i++){
            int nomorMemberCharge = Database.charge.get(i).idMember;

            if(idMember == nomorMemberCharge){
                namaLokasi.add(Database.charge.get(i).namaLokasi);
                alamatLokasi.add(Database.charge.get(i).alamatLokasi);
                totalHarga.add(Database.charge.get(i).totalHarga);
            }
        }

        ListChargeHistory tampilinIsi = new ListChargeHistory(OrderHistory.this, idMember, namaLokasi, alamatLokasi, totalHarga);
        listCharge.setAdapter(tampilinIsi);
    }
}
