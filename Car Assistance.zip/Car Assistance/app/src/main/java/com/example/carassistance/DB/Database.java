package com.example.carassistance.DB;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.Toast;

import com.example.carassistance.DB.Models.Charge;
import com.example.carassistance.DB.Models.Lokasi;
import com.example.carassistance.DB.Models.Parking;
import com.example.carassistance.DB.Models.User;

import java.util.Vector;

public class Database {
    public static Vector<User> users = new Vector<>();
    public static Vector<Lokasi> lokasi = new Vector<>();
    public static Vector<Parking> parking = new Vector<>();
    public static Vector<Charge> charge = new Vector<>();

    public static boolean HAS_SYNC = false;

    public static void insertUser(String nama, String email, String password, String telepon, Context ctx) {
        User u = new User(nama,email,password,telepon);
        u.id = users.size() + 1;
        users.add(u);

        DBHelper helper = new DBHelper(ctx);
        SQLiteDatabase db = helper.getWritableDatabase();

        String query = String.format("INSERT INTO users(fullname, email, password, phonenumber) VALUES ('%s', '%s', '%s', '%s')", nama, email, password, telepon);
        db.execSQL(query);
    }

    public static void insertParking(int idMember, String namaLokasi, String alamatLokasi, String tanggalParkir, String hargaLokasi, Context ctx){
        Parking p = new Parking(idMember, namaLokasi, alamatLokasi, tanggalParkir, hargaLokasi);

        DBHelper helper = new DBHelper(ctx);
        SQLiteDatabase db = helper.getWritableDatabase();

        String queryParking = "SELECT * FROM parkings";
        Cursor c = db.rawQuery(queryParking, null);

        if(c.moveToLast()){
            int i = c.getInt(0);
            p.idParking = i+1;
            parking.add(p);

            String query = String.format("INSERT INTO parkings(idParking, idMember, namaLokasi, alamatLokasi, tanggalParkir, totalHarga) VALUES ('%d', '%d', '%s', '%s', '%s', '%s')", i+1, idMember, namaLokasi, alamatLokasi, tanggalParkir, hargaLokasi);
            db.execSQL(query);
        }else {
            p.idParking = 1;
            parking.add(p);

            String query = String.format("INSERT INTO parkings(idParking, idMember, namaLokasi, alamatLokasi, tanggalParkir, totalHarga) VALUES ('%d', '%d', '%s', '%s', '%s', '%s')", 1, idMember, namaLokasi, alamatLokasi, tanggalParkir, hargaLokasi);
            db.execSQL(query);
        }
    }

    public static void insertCharge(int idMember, String namaLokasi, String alamatLokasi, String totalHarga, Context ctx){
        Charge ch = new Charge(idMember, namaLokasi, alamatLokasi, totalHarga);

        DBHelper helper = new DBHelper(ctx);
        SQLiteDatabase db = helper.getWritableDatabase();

        String queryCharge = "SELECT * FROM charges";
        Cursor c = db.rawQuery(queryCharge, null);

        if(c.moveToLast()){
            int i = c.getInt(0);
            ch.idCharge = i+1;
            charge.add(ch);

            String query = String.format("INSERT INTO charges(idCharge, idMember, namaLokasi, alamatLokasi, totalHarga) VALUES ('%d', '%d', '%s', '%s', '%s')", i+1, idMember, namaLokasi, alamatLokasi, totalHarga);
            db.execSQL(query);
        }else {
            ch.idCharge = 1;
            charge.add(ch);

            String query = String.format("INSERT INTO charges(idCharge, idMember, namaLokasi, alamatLokasi, totalHarga) VALUES ('%d', '%d', '%s', '%s', '%s')", 1, idMember, namaLokasi, alamatLokasi, totalHarga);
            db.execSQL(query);
        }
    }

    public static void generateFirstData(){
        if(lokasi.isEmpty()){
            //Data Hotel
            Lokasi lokasi1 = new Lokasi();
            lokasi1.idLokasi = 1;
            lokasi1.namaLokasi = "Mall Kelapa Gading";
            lokasi1.alamatLokasi = "jl. Bundaran Kelapa Gading,Blok M Kelapa Gading Timur RT.13, RT.13/RW.13, Klp. Gading Tim., Kec. Klp. Gading, Kota Jkt Utara, Daerah Khusus Ibukota Jakarta 14240";
            lokasi1.hargaLokasi = 15000;
            lokasi1.latLokasi = -6.157411;
            lokasi1.longLokasi = 106.907725;
            lokasi.add(lokasi1);

            Lokasi lokasi2 = new Lokasi();
            lokasi2.idLokasi = 2;
            lokasi2.namaLokasi = "Summarecon Mall Bekasi";
            lokasi2.alamatLokasi = "Jl. Bulevar Ahmad Yani, RT.006/RW.002, Marga Mulya, Kec. Bekasi Utara, Kota Bks, Jawa Barat 17142";
            lokasi2.hargaLokasi = 10000;
            lokasi2.latLokasi = -6.225709;
            lokasi2.longLokasi = 107.001061;
            lokasi.add(lokasi2);

            Lokasi lokasi3 = new Lokasi();
            lokasi3.idLokasi = 3;
            lokasi3.namaLokasi = "Mall Taman Anggrek";
            lokasi3.alamatLokasi = "Jl. Letjen S. Parman No.28, RT.12/RW.1, Tomang, Kec. Grogol petamburan, Kota Jakarta Barat, Daerah Khusus Ibukota Jakarta 11440";
            lokasi3.hargaLokasi = 25000;
            lokasi3.latLokasi = -6.178303;
            lokasi3.longLokasi = 106.792230;
            lokasi.add(lokasi3);

            Lokasi lokasi4 = new Lokasi();
            lokasi4.idLokasi = 4;
            lokasi4.namaLokasi = "Summarecon Mall Serpong";
            lokasi4.alamatLokasi = "Gading Serpong, Sentra, Jl. Boulevard Raya Gading Serpong, Klp. Dua, Kec. Klp. Dua, Tangerang, Banten 15810";
            lokasi4.hargaLokasi = 15000;
            lokasi4.latLokasi = -6.240825;
            lokasi4.longLokasi = 106.628518;
            lokasi.add(lokasi4);

            Lokasi lokasi5 = new Lokasi();
            lokasi5.idLokasi = 5;
            lokasi5.namaLokasi = "IKEA Alam Sutera";
            lokasi5.alamatLokasi = "Jl. Jalur Sutera Boulevard No.Kav.45, RT.002/RW.002, Kunciran, Kec. Pinang, Kota Tangerang, Banten 15320";
            lokasi5.hargaLokasi = 20000;
            lokasi5.latLokasi = -6.220123;
            lokasi5.longLokasi = 106.663123;
            lokasi.add(lokasi5);
        }
    }

    public static boolean exampleSelect(Context ctx) {
        DBHelper helper = new DBHelper(ctx);
        SQLiteDatabase db = helper.getReadableDatabase();

        String queryCharge = "SELECT * FROM parkings";

        Cursor c = db.rawQuery(queryCharge, null);

        while (c.moveToNext()) {

            int i = c.getInt(0);
            int n = c.getInt(1);
            String p = c.getString(2);
            String t = c.getString(3);
            String o = c.getString(4);
            String y = c.getString(5);

            Log.d("DATABASE", String.format("%d, %d, %s, %s, %s, %s", i, n, p, t, o, y));
        }
        c.close();
        return true;
    }

    public static void sync(Context ctx){
        if(HAS_SYNC = true){
            return;
        }

        HAS_SYNC = true;

        String SQL_SELECT_USER = "SELECT * FROM users";
        String SQL_SELECT_PARKING = "SELECT * FROM parkings";
        String SQL_SELECT_CHARGE = "SELECT * FROM charges";

        DBHelper helper = new DBHelper(ctx);
        SQLiteDatabase db = helper.getReadableDatabase();

        Cursor c = db.rawQuery(SQL_SELECT_USER, null);
        while(c.moveToNext()){
            User u = new User(c.getString(1), c.getString(2), c.getString(3), c.getString(4));
            u.id = c.getInt(0);
            users.add(u);
        }
        c.close();

        Cursor c1 = db.rawQuery(SQL_SELECT_PARKING, null);
        while(c1.moveToNext()){
            Parking p = new Parking(c1.getInt(1), c1.getString(2), c1.getString(3), c1.getString(4), c1.getString(5));
            p.idParking = c1.getInt(0);
            parking.add(p);
        }
        c1.close();

        Cursor c2 = db.rawQuery(SQL_SELECT_CHARGE, null);
        while(c2.moveToNext()){
            Charge ch = new Charge(c2.getInt(1), c2.getString(2), c2.getString(3), c2.getString(4));
            ch.idCharge = c2.getInt(0);
            charge.add(ch);
        }
        c2.close();
    }
}
