package com.example.carassistance.DB;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public static String DB_NAME = "carAssistance";
    public static int DB_VERSION = 2;

    public static String SQL_CREATE_USERS_TABLE =
            "CREATE TABLE IF NOT EXISTS users(" +
                    "idUser integer primary key autoincrement," +
                    "fullname text," +
                    "email text," +
                    "password text," +
                    "phonenumber text" +
                    ")";

    public static String SQL_CREATE_PARKING_TABLE =
            "CREATE TABLE IF NOT EXISTS parkings(" +
                    "idParking integer primary key," +
                    "idMember integer," +
                    "namaLokasi text," +
                    "alamatLokasi text," +
                    "tanggalParkir text," +
                    "totalHarga text" +
                    ")";

    public static String SQL_CREATE_CHARGE_TABLE =
            "CREATE TABLE IF NOT EXISTS charges(" +
                    "idCharge integer primary key," +
                    "idMember integer," +
                    "namaLokasi text," +
                    "alamatLokasi text," +
                    "totalHarga text" +
                    ")";

    public static String SQL_DROP_USERS_TABLE = "DROP TABLE IF EXISTS users";
    public static String SQL_DROP_PARKING_TABLE = "DROP TABLE IF EXISTS parkings";
    public static String SQL_DROP_CHARGE_TABLE = "DROP TABLE IF EXISTS charges";

    void refreshTable(SQLiteDatabase db) {
        db.execSQL(SQL_DROP_USERS_TABLE);
        db.execSQL(SQL_CREATE_USERS_TABLE);

        db.execSQL(SQL_DROP_PARKING_TABLE);
        db.execSQL(SQL_CREATE_PARKING_TABLE);

        db.execSQL(SQL_DROP_CHARGE_TABLE);
        db.execSQL(SQL_CREATE_CHARGE_TABLE);
    }

    public DBHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        refreshTable(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        refreshTable(db);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        refreshTable(db);
    }
}
