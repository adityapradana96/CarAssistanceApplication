package com.example.carassistance.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.carassistance.ChargeDetail;
import com.example.carassistance.DB.Database;
import com.example.carassistance.DB.Models.Lokasi;
import com.example.carassistance.ParkDetail;
import com.example.carassistance.R;

public class ListParkAdapter extends BaseAdapter {
    Context ctx;
    int idMember;
    String telepon;

    public ListParkAdapter(Context ctx, int idMember, String telepon) {
        this.ctx = ctx;
        this.idMember = idMember;
        this.telepon = telepon;
    }

    @Override
    public int getCount() {
        return Database.lokasi.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View detailPark = LayoutInflater.from(ctx).inflate(R.layout.listparkspot, null, false);

        final Lokasi l = Database.lokasi.get(position);

        TextView namaPark = detailPark.findViewById(R.id.ListNamaParkir);
        TextView alamatPark = detailPark.findViewById(R.id.ListAlamatParkir);
        TextView hargaPark = detailPark.findViewById(R.id.ListHargaParkir);

        String hargaLokasi = Integer.toString(l.hargaLokasi);

        namaPark.setText(l.namaLokasi);
        alamatPark.setText(l.alamatLokasi);
        hargaPark.setText(hargaLokasi);

        detailPark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent parkDetail = new Intent(ctx, ParkDetail.class);
                parkDetail.putExtra("idLokasi", l.idLokasi);
                parkDetail.putExtra("namaLokasi", l.namaLokasi);
                parkDetail.putExtra("alamatLokasi", l.alamatLokasi);
                parkDetail.putExtra("latLokasi", l.latLokasi);
                parkDetail.putExtra("longLokasi", l.longLokasi);
                parkDetail.putExtra("hargaLokasi", l.hargaLokasi);
                parkDetail.putExtra("idMember", idMember);
                parkDetail.putExtra("teleponMember", telepon);
                ctx.startActivity(parkDetail);
            }
        });
        return detailPark;
    }
}

