package com.example.carassistance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ListView;

import com.example.carassistance.Adapter.ListRechargeAdapter;

public class Recharge extends AppCompatActivity {
    WebView webView;
    ListView lvCharge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recharge);

        webView = findViewById(R.id.recharge);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        String file = "file:android_asset/gifcharge.gif";
        webView.loadUrl(file);

        lvCharge = findViewById(R.id.Recharge_ListView_ListRecharge);

        Intent getData = getIntent();
        int idMember = getData.getIntExtra("idMember",0);
        String telepon = getData.getStringExtra("teleponMember");

        ListRechargeAdapter tampilinIsi = new ListRechargeAdapter(this, idMember, telepon);
        lvCharge.setAdapter(tampilinIsi);
    }
}
