package com.example.carassistance.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.carassistance.DB.Database;
import com.example.carassistance.R;

import java.util.Vector;

public class ListChargeHistory extends BaseAdapter {

    Context ctx;
    int idMember;

    public static Vector<String> namaLokasi = new Vector<>();
    public static Vector<String> alamatLokasi = new Vector<>();
    public static Vector<String> totalHarga = new Vector<>();

    public ListChargeHistory(Context ctx, int idMember, Vector<String> namaLokasi, Vector<String> alamatLokasi, Vector<String> totalHarga) {
        this.ctx = ctx;
        this.idMember = idMember;
        this.namaLokasi = namaLokasi;
        this.alamatLokasi = alamatLokasi;
        this.totalHarga = totalHarga;
    }

    @Override
    public int getCount() {
        return namaLokasi.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View charge = LayoutInflater.from(ctx).inflate(R.layout.listorderhistory, null, false);

        TextView txtNamaLokasi = charge.findViewById(R.id.OrderNamaCharging);
        TextView txtAlamatLokasi = charge.findViewById(R.id.OrderAlamatCharging);
        TextView txtTotalHarga = charge.findViewById(R.id.OrderTotalCharging);

        txtNamaLokasi.setText(namaLokasi.get(position));
        txtAlamatLokasi.setText(alamatLokasi.get(position));
        txtTotalHarga.setText(totalHarga.get(position));

        return charge;
    }
}
