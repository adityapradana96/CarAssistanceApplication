package com.example.carassistance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;

import com.example.carassistance.Adapter.ListChargeHistory;
import com.example.carassistance.Adapter.ListParkingHistory;
import com.example.carassistance.DB.Database;

import java.util.Vector;

public class MyBookings extends AppCompatActivity {

    public static Vector<String> namaLokasi = new Vector<>();
    public static Vector<String> alamatLokasi = new Vector<>();
    public static Vector<String> tanggalParkir = new Vector<>();
    public static Vector<String> totalHarga = new Vector<>();
    public static Vector<Integer> idParking = new Vector<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_bookings);

        Intent getData = getIntent();
        final int idMember = getData.getIntExtra("idMember",0);

        ListView listCharge = findViewById(R.id.ListViewMyBookings);

        namaLokasi.clear();
        alamatLokasi.clear();
        tanggalParkir.clear();
        totalHarga.clear();
        idParking.clear();

        Database.exampleSelect(MyBookings.this);

        for (int i = 0; i < Database.parking.size(); i++){
            int nomorMemberCharge = Database.parking.get(i).idMember;

            if(idMember == nomorMemberCharge){
                namaLokasi.add(Database.parking.get(i).namaLokasi);
                alamatLokasi.add(Database.parking.get(i).alamatLokasi);
                tanggalParkir.add(Database.parking.get(i).tanggalParkir);
                totalHarga.add(Database.parking.get(i).hargaLokasi);
                idParking.add(Database.parking.get(i).idParking);
            }
        }

        ListParkingHistory tampilinIsi = new ListParkingHistory(MyBookings.this, idMember, namaLokasi, alamatLokasi, tanggalParkir, totalHarga, idParking);
        listCharge.setAdapter(tampilinIsi);
    }
}
