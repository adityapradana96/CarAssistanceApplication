package com.example.carassistance.DB.Models;

public class User {
    public int id;
    public String nama, email, password, telepon;

    public User(String nama, String email, String password, String telepon){
        this.nama = nama;
        this.email = email;
        this.password = password;
        this.telepon = telepon;
    }
}
