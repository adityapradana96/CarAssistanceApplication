package com.example.carassistance;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapActivity extends FragmentActivity implements OnMapReadyCallback {

    GoogleMap mapAPI;
    SupportMapFragment mapFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapAPI);
        mapFragment.getMapAsync(MapActivity.this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mapAPI = googleMap;

        Intent getData = getIntent();
        Double latLokasi = getData.getDoubleExtra("latLokasi", 0);
        Double longLokasi = getData.getDoubleExtra("longLokasi",0);
        String namaLokasi = getData.getStringExtra("namaLokasi");

        Log.d("Map", "" + latLokasi + " " + longLokasi);

        LatLng lokasi = new LatLng(latLokasi, longLokasi);
        mapAPI.addMarker(new MarkerOptions().position(lokasi).title(namaLokasi));
        mapAPI.moveCamera(CameraUpdateFactory.newLatLng(lokasi));
        mapAPI.setMinZoomPreference(14.0f);
        mapAPI.setMaxZoomPreference(28.0f);
    }
}
