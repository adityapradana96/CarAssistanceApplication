package com.example.carassistance;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import com.example.carassistance.DB.Database;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class ParkDetail extends AppCompatActivity {

    TextView txtNamaParkir, txtAlamatParkir, txtHargaParkir, txtTanggalParkir, txtTotalHarga;
    Button btnCheckMap, btnPilihTanggal, btnOrder;
    Date checkInDate;

    final int SEND_SMS_PERMISSION_REQUEST_CODE = 1;

    void init(){
        txtNamaParkir = findViewById(R.id.DetailParkirNama);
        txtAlamatParkir = findViewById(R.id.DetailParkirAlamat);
        txtHargaParkir = findViewById(R.id.DetailParkirHarga);
        txtTanggalParkir = findViewById(R.id.DetailParkirTulisanDate);
        txtTotalHarga = findViewById(R.id.DetailParkirTulisanTotal);

        btnCheckMap = findViewById(R.id.btnMap_ParkDetail);
        btnPilihTanggal = findViewById(R.id.DetailParkirButtonDate);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_park_detail);

        init();

        Intent getData = getIntent();
        final String namaLokasi = getData.getStringExtra("namaLokasi");
        final String alamatLokasi = getData.getStringExtra("alamatLokasi");
        final Double latLokasi = getData.getDoubleExtra("latLokasi", 0);
        final Double longLokasi = getData.getDoubleExtra("longLokasi", 0);
        final int hargaLokasi = getData.getIntExtra("hargaLokasi", 0);
        final int idMember = getData.getIntExtra("idMember", 0);
        final String telepon = getData.getStringExtra("teleponMember");

        String harga = Integer.toString(hargaLokasi);

        txtNamaParkir.setText(namaLokasi);
        txtAlamatParkir.setText(alamatLokasi);
        txtHargaParkir.setText("Rp "+harga);
        txtTotalHarga.setText("Rp "+harga);

        if (checkPermission(Manifest.permission.SEND_SMS)){

        }else{
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SEND_SMS_PERMISSION_REQUEST_CODE);
        }

        btnPilihTanggal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog1();
            }
        });

        btnCheckMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cekMap = new Intent(ParkDetail.this, MapActivity.class);
                cekMap.putExtra("latLokasi", latLokasi);
                cekMap.putExtra("longLokasi", longLokasi);
                cekMap.putExtra("namaLokasi", namaLokasi);
                startActivity(cekMap);
            }
        });

        btnOrder = findViewById(R.id.btnOrder_DetailParking);
        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tanggalParkir = txtTanggalParkir.getText().toString();
                String harga = Integer.toString(hargaLokasi);
                if(tanggalParkir.equals("Tanggal Parkir")){
                    Toast.makeText(ParkDetail.this, "Choose Park Date!", Toast.LENGTH_SHORT).show();
                }else{
                    if(checkPermission(Manifest.permission.SEND_SMS)){
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(telepon, null, "Thank you for booking our park" +"\n"+
                                        "Location: "+ namaLokasi +"\n"+
                                        "Parking Date: "+ tanggalParkir +"\n"+
                                        "Total Price: "+ harga,
                                null, null);
                        Toast.makeText(ParkDetail.this,"Thank you for booking our park", Toast.LENGTH_SHORT).show();

                        Database.insertParking(idMember, namaLokasi, alamatLokasi, tanggalParkir, harga, ParkDetail.this);
                    }else{
                        Toast.makeText(ParkDetail.this, "Permission Denied!", Toast.LENGTH_SHORT).show();
                    }

                    Intent home = new Intent(ParkDetail.this, HomeActivity.class);
                    home.putExtra("idMember", idMember);
                    home.putExtra("teleponMember", telepon);
                    startActivity(home);
                    finish();
                }
            }
        });
    }

    public void showDatePickerDialog1(){
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                String date = dayOfMonth + "/" + (month+1) + "/" + year;

                Date currentDate = new Date();

                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

                String currentDateString = sdf.format(currentDate);

                try{
                    checkInDate = sdf.parse(date);
                }catch (Exception e){

                }

                if(compareDate(checkInDate, currentDate) < 0){
                    Toast.makeText(ParkDetail.this, "Check in date must not before today", Toast.LENGTH_LONG).show();
                    txtTanggalParkir.setText(currentDateString);
                }else{
                    txtTanggalParkir.setText(date);
                }
            }
        }, Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    public long compareDate(Date date1, Date date2){
        long diff = (date1.getTime() - date2.getTime()) / 86400000;
        return diff;
    }

    public boolean checkPermission(String permission){
        int check = ContextCompat.checkSelfPermission(this, permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }
}
