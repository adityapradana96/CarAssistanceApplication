package com.example.carassistance.DB.Models;

public class Charge {
    public int idCharge, idMember;
    public String namaLokasi, alamatLokasi, totalHarga;

    public Charge(int idMember, String namaLokasi, String alamatLokasi, String totalHarga){
        this.idMember = idMember;
        this.namaLokasi = namaLokasi;
        this.alamatLokasi = alamatLokasi;
        this.totalHarga = totalHarga;
    }
}
