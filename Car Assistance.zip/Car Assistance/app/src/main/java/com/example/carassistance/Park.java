package com.example.carassistance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;

import com.example.carassistance.Adapter.ListParkAdapter;
import com.example.carassistance.Adapter.ListRechargeAdapter;

public class Park extends AppCompatActivity {

    ListView lvPark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_park);

        lvPark = findViewById(R.id.Park_ListView_ListPark);

        Intent getData = getIntent();
        int idMember = getData.getIntExtra("idMember",0);
        String telepon = getData.getStringExtra("teleponMember");

        ListParkAdapter tampilinIsi = new ListParkAdapter(this, idMember, telepon);
        lvPark.setAdapter(tampilinIsi);
    }
}
