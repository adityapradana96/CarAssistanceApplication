package com.example.carassistance;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.carassistance.DB.Database;

public class HomeActivity extends AppCompatActivity {
    Button charge, park;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent getData = getIntent();
        final int idMember = getData.getIntExtra("idMember",0);

        switch (item.getItemId()) {
            case R.id.item1:
                Intent intent = new Intent(HomeActivity.this, MyBookings.class);
                intent.putExtra("idMember", idMember);
                startActivity(intent);
                return true;

            case R.id.item2:
                Intent intent1 = new Intent(HomeActivity.this, OrderHistory.class);
                intent1.putExtra("idMember", idMember);
                startActivity(intent1);
                return true;

            case R.id.item3:
                Intent intent2 = new Intent(HomeActivity.this, SignIn.class);
                startActivity(intent2);
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Intent getData = getIntent();
        final int idMember = getData.getIntExtra("idMember",0);
        final String telepon = getData.getStringExtra("teleponMember");

        Database.exampleSelect(HomeActivity.this);

        getSupportActionBar().setIcon(R.drawable.belakangnyasignup);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        charge = findViewById(R.id.Home_ButtonCharge);
        park = findViewById(R.id.Home_ButtonPark);

        charge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, Recharge.class);
                intent.putExtra("idMember", idMember);
                intent.putExtra("teleponMember", telepon);
                startActivity(intent);
            }
        });

        park.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, Park.class);
                intent.putExtra("idMember", idMember);
                intent.putExtra("teleponMember", telepon);
                startActivity(intent);
            }
        });
    }
}
